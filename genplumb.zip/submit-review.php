<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch form data
    $reviewerName = $_POST['reviewerName'];
    $rating = $_POST['rating'];
    $description = $_POST['description'];

    // Save the data to a file, database, or perform other actions based on your application's needs

    // For example, save the data to a file (append to a text file)
    $file = 'reviews.txt';
    $content = "Reviewer: $reviewerName, Rating: $rating, Review: $description\n";

    // Append the review to the file
    file_put_contents($file, $content, FILE_APPEND | LOCK_EX);

    // Return a response if needed
    echo 'Review submitted successfully!';
} else {
    // Handle other cases or errors
    echo 'Error: Form not submitted!';
}
?>
