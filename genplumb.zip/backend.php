<?php
// backend.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch data from the form
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Process the data or perform any required actions (e.g., send an email, store data in a database, etc.)
    // Example: sending an email
    $to = "coreysadler811@gmail.com";
    $subject = "New Inquiry";
    $body = "Name: $name\nEmail: $email\nMessage: $message";

    // Use appropriate headers here if sending an email
    // mail($to, $subject, $body);
    
    // You can add further logic here based on your requirements
}
?>